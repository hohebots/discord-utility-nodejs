const { Events, ModalBuilder } = require('discord.js');

async function create(title, id) {
	const modal = new ModalBuilder()
	.setCustomId(id)
	.setTitle(title);

	return modal
}


module.exports = {
    create: create
}

