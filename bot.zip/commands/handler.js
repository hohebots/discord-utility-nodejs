const ping = require("../commands/ping.js")
const setup = require("../commands/setup.js")
const log = require("../util/log.js")

async function handle(command, client, interaction) {
    if (command == "ping") {
        ping.run(client, interaction)
        log.info("Command " + command + "ausgeführt")
        
    } else if (command == "setup") {
        setup.run(client, interaction)
        log.info("Command " + command + "ausgeführt")
    } 
}

module.exports = {
    handle: handle
}