const { SlashCommandBuilder } = require('@discordjs/builders');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const config = require("../config/load.js")
const log = require("../util/log.js")

async function commands() {
    const conf = await config.load()
    const settings = conf.settings.auth
    const configCommands = conf.commands
    var commands = []

    Object.keys(configCommands).forEach(function(commandName) {
        commands.push(new SlashCommandBuilder().setName(configCommands[commandName]["name"]).setDescription(configCommands[commandName]["description"]))
    })
    
    commands = commands.map(command => command.toJSON());

    const rest = new REST({ version: '9' }).setToken(settings["token"]);

    rest.put(Routes.applicationGuildCommands(settings["clientId"], settings["guildId"]), { body: commands })
        .then(() => log.info("Commands wurden registriert"))
        .catch(console.error);
}

module.exports = {
    commands: commands
}

commands()