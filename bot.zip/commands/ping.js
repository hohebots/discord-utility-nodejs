async function run(client, interaction) {
    await interaction.reply('Pong!');
}

module.exports = {
    run: run
}